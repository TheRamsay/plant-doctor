## Plant doctor 🪴🩺🩻

```
Author: Dominik Huml (xhumld00@vutbr.cz)
```

School project for subject IMP (Microprocessors and Embedded Systems). Simple system for monitoring health of your poor plants, and integration with Home Assistent.
