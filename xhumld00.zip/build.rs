fn main() {
    embuild::espidf::sysenv::output();
}
