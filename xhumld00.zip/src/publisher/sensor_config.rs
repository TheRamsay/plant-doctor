pub struct SensorConfig {
    pub topic: String,
}